# FocusBoard Analytics Dashboard - Implementation Tasks

This document breaks down the PRD into atomic, trackable tasks grouped by implementation phase.

## Phase 1: Event Logging Infrastructure
**Goal:** Silently log events from the new-tab page into `chrome.storage.local`.
**Dependencies:** None

- [x] **1.1. Core Analytics Module Setup**
  - [x] Create `analytics.js` file.
  - [x] Implement date helper to get today's key (e.g., `YYYY-MM-DD`).
  - [x] Implement `logEvent(type, meta)` function stub.
- [x] **1.2. `logEvent` Implementation Details**
  - [x] Read `focusboard_analytics` from `chrome.storage.local` (default to empty object).
  - [x] Parse and update today's `DailyRecord` based on the event type.
  - [x] Implement logic to prune keys older than 30 days.
  - [x] Write the updated object back to storage.
- [x] **1.3. Wire up task completion logging**
  - [x] In `newtab.js`, locate the task completion handler.
  - [x] Add `logEvent('task_completed')` on task completion.
- [x] **1.4. Wire up focus session logging**
  - [x] In `newtab.js`, locate Focus Mode ON toggle.
  - [x] Store start time: `window._focusStart = Date.now()`.
  - [x] Add `logEvent('focus_mode_on')`.
  - [x] In `newtab.js`, locate Focus Mode OFF toggle.
  - [x] Calculate focus duration in minutes.
  - [x] Add `logEvent('focus_mode_off', { minutes })`.
- [x] **1.5. Wire up blocked site logging**
  - [x] In `background.js`, locate the web request interception logic.
  - [x] Extract the hostname of the blocked attempt.
  - [x] Add `logEvent('site_blocked', { domain })`.
- [ ] **1.6. Phase 1 Verification**
  - [ ] Verify `task_completed` increments in storage.
  - [ ] Verify `focusMinutes` calculates and stores correctly.
  - [ ] Verify `blockedSiteAttempts` tracks domains accurately.

## Phase 2: Analytics View Shell
**Goal:** Add the UI shell for the Analytics panel to the new-tab page.
**Dependencies:** Phase 1 (Basic structure)

- [x] **2.1. UI Markup Updates**
  - [x] In `newtab.html`, add `<button id="analytics-btn">` to the header/toolbar.
  - [x] Add `#analytics-panel` `<div>` containing back button, title, and `#charts-container`. Set `hidden` attribute by default.
- [x] **2.2. Dependencies & Permissions**
  - [x] Add Chart.js CDN `<script>` tag to `newtab.html`.
  - [x] Update `manifest.json` CSP to allow `cdn.jsdelivr.net` if required.
- [x] **2.3. View Toggle Logic**
  - [x] In `newtab.js`, add event listener to `#analytics-btn` to hide `#main-dashboard` and show `#analytics-panel`.
  - [x] Add event listener to the back button in `#analytics-panel` to reverse the toggle.
- [x] **2.4. `renderAnalytics` Stub Implementation**
  - [x] Create `analyticsCharts.js` (or add to `newtab.js`).
  - [x] Read `focusboard_analytics` from storage.
  - [x] Handle empty state: Render "No data yet" message if storage is empty or zeroed out.
- [ ] **2.5. Phase 2 Verification**
  - [ ] Verify toggling between views works seamlessly.
  - [ ] Verify empty state displays when no analytics data exists.

## Phase 3: Charts & Stats
**Goal:** Render data visualizations inside the charts container.
**Dependencies:** Phase 1 (Data), Phase 2 (Shell)

- [x] **3.1. Data Preparation**
  - [x] Write a helper function to format the last 7 days' data into arrays suitable for Chart.js (labels, data points).
- [x] **3.2. Summary KPI Cards**
  - [x] Create CSS layout for the top KPI row.
  - [x] Calculate "Tasks This Week" (sum of 7 days).
  - [x] Calculate "Focus Streak" (consecutive days backward from today).
  - [x] Calculate "Temptations Blocked" (sum of blocked attempts).
  - [x] Render KPI values into the DOM.
- [x] **3.3. Chart 1: Tasks Completed**
  - [x] Initialize Bar chart for tasks completed.
  - [x] Configure y-axis to begin at zero with integer steps.
  - [x] Set color to solid blue (`#4A90D9`).
- [x] **3.4. Chart 2: Focus Time**
  - [x] Initialize Bar chart for focus minutes.
  - [x] Configure y-axis to begin at zero.
  - [x] Set color to solid green (`#27AE60`).
- [x] **3.5. Chart 3: Focus Sessions**
  - [x] Initialize Line chart for session count.
  - [x] Configure with filled area (`fill: true`).
  - [x] Set color to purple (`#8E44AD`).
- [x] **3.6. Chart 4: Blocked Site Attempts**
  - [x] Aggregate blocked sites across 7 days, sort descending, slice top 5.
  - [x] Initialize Horizontal Bar or Doughnut chart.
  - [x] Handle empty state ("No blocked sites attempted").
- [ ] **3.7. Phase 3 Verification**
  - [ ] Verify all charts render with sample data.
  - [ ] Verify KPI numbers match raw storage values.

## Phase 4: Polish & Edge Cases
**Goal:** Make the dashboard robust and production-ready.
**Dependencies:** Phase 3

- [x] **4.1. Chart Lifecycle Management**
  - [x] Maintain a map of active Chart instances.
  - [x] Call `chart.destroy()` on existing instances before re-rendering to prevent canvas errors.
- [x] **4.2. Data Edge Cases**
  - [x] Handle partial days: Change today's x-axis label to "Today".
  - [x] Handle missing days: Inject zero-value data points for days without records to maintain a 7-day scale.
  - [x] Implement storage migration guard: Wrap storage read in try/catch and wipe if JSON is malformed.
- [x] **4.3. Accessibility & Styling**
  - [x] Add `aria-label` and `role="img"` to all `<canvas>` elements.
  - [x] Add descriptive `aria-label`s to KPI cards.
  - [x] Update `Chart.defaults.font.family` to match extension typography.
  - [x] Finalize CSS grid layouts (`analytics.css`).
- [ ] **4.4. Phase 4 Verification**
  - [ ] Open analytics multiple times to ensure no canvas duplication errors.
  - [ ] Verify layout responsiveness.
  - [ ] Review manual QA checklist in PRD.
