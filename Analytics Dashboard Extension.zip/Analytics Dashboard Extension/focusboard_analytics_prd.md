# PRD: FocusBoard Analytics Dashboard
### Assignment 9 — Chrome Extension Personal Productivity Dashboard

---

## Overview

Build an **Analytics view** inside the FocusBoard Chrome extension (new-tab productivity dashboard) that visualises the user's focus and task activity over the past 7 days. The view is accessible from a dedicated **Analytics button** in the existing FocusBoard UI. It renders charts and summary stats derived from events logged silently in the background.

---

## Goals

| Goal | Success Signal |
|---|---|
| Log the right events without bloating storage | Storage stays under 50 KB after a week of normal use |
| Surface 4 meaningful charts | Charts render correctly and reflect real usage |
| Numbers are accurate | Completing 3 tasks shows "3" in the task chart, not 0 or 5 |
| Dashboard is accessible | User can open Analytics in one click from the new-tab page |

---

## Non-Goals

- No server-side storage or sync across devices
- No export or sharing functionality
- No alerts or nudges based on analytics data
- No history beyond 30 days (storage cap)

---

## Architecture Overview

```
New Tab Page (newtab.html / newtab.js)
    ├── Main dashboard view  (existing)
    └── Analytics view       (new — toggled in-page)

background.js (service worker)
    ├── Listens for events from newtab.js
    └── Writes aggregated daily summaries to chrome.storage.local

chrome.storage.local
    └── focusboard_events: DailyRecord[]   (capped at 30 days)
```

The Analytics view is a **second view rendered inside the same newtab page** (not a separate HTML page). A toggle button swaps `display` between the main dashboard and the analytics panel.

---

## Data Model

### Event Types to Log

| Event Key | When to Fire |
|---|---|
| `task_completed` | User marks a task as done |
| `focus_mode_on` | Focus Mode toggled ON |
| `focus_mode_off` | Focus Mode toggled OFF |
| `site_blocked` | A blocked site is intercepted while Focus Mode is on |

### Storage Schema

Rather than storing raw events (which balloons storage), aggregate into **daily summaries**. Each midnight, or on the first event of a new day, write a `DailyRecord`.

```jsonc
// chrome.storage.local key: "focusboard_analytics"
{
  "2025-07-14": {
    "tasksCompleted": 4,
    "focusSessionCount": 2,
    "focusMinutes": 47,
    "blockedSiteAttempts": {
      "instagram.com": 3,
      "youtube.com": 1
    }
  },
  "2025-07-15": { ... }
}
```

- **Max 30 keys** (30 days). On write, evict any key older than 30 days.
- `focusMinutes` is calculated as the delta between `focus_mode_on` and the next `focus_mode_off` (or tab close). Store an in-memory `focusStartTime` in the service worker; do not persist raw timestamps.

---

## Phase 1 — Event Logging Infrastructure

**Goal:** Silently log events from the new-tab page into `chrome.storage.local` with zero visible UI changes.

### Tasks

1. **Add `logEvent(type, meta?)` helper** in a shared `analytics.js` module:
   - Reads today's date key (`YYYY-MM-DD`).
   - Reads current `focusboard_analytics` object from storage (default `{}`).
   - Updates today's `DailyRecord` in-memory.
   - Writes it back.
   - Prunes keys older than 30 days before writing.

2. **Wire up existing event sources** in `newtab.js`:
   - Task complete handler → `logEvent('task_completed')`
   - Focus Mode toggle ON → `logEvent('focus_mode_on')`
   - Focus Mode toggle OFF → `logEvent('focus_mode_off')`

3. **Track focus duration** in `newtab.js`:
   - On `focus_mode_on`: store `window._focusStart = Date.now()`
   - On `focus_mode_off`: compute `Math.round((Date.now() - window._focusStart) / 60000)` and pass as `meta.minutes` to `logEvent`

4. **Wire up blocked-site logging** in `background.js` (service worker):
   - In the existing `webRequest` / `declarativeNetRequest` handler, call `logEvent('site_blocked', { domain })` after extracting the hostname.

### Acceptance Criteria — Phase 1

- [ ] Complete 2 tasks → `storage.local.focusboard_analytics["<today>"].tasksCompleted === 2`
- [ ] Toggle Focus Mode on for ~2 minutes, then off → `focusMinutes >= 1`
- [ ] Navigate to a blocked site → `blockedSiteAttempts` key increments
- [ ] No console errors during normal use
- [ ] Storage object stays under 5 KB after one full day of testing

---

## Phase 2 — Analytics View Shell

**Goal:** Add an Analytics panel to the new-tab page that can be opened and closed, with a loading state and empty-state message.

### Tasks

1. **Add Analytics button** to the existing FocusBoard toolbar/header:
   ```html
   <button id="analytics-btn" aria-label="View Analytics">📊 Analytics</button>
   ```

2. **Add `#analytics-panel` div** in `newtab.html`, initially `display: none`:
   ```html
   <div id="analytics-panel" hidden>
     <button id="analytics-close">← Back</button>
     <h2>Your Focus Week</h2>
     <div id="charts-container"><!-- charts injected here --></div>
   </div>
   ```

3. **Toggle logic** in `newtab.js`:
   - Click `#analytics-btn` → hide `#main-dashboard`, show `#analytics-panel`, call `renderAnalytics()`
   - Click `#analytics-close` → reverse

4. **`renderAnalytics()` stub**:
   - Reads `focusboard_analytics` from storage
   - If object is empty or all-zero → render "No data yet. Complete some tasks and use Focus Mode to see your stats here."
   - Otherwise → pass data to chart-rendering functions (Phase 3)

5. **Install Chart.js** via CDN in `newtab.html`:
   ```html
   <script src="https://cdn.jsdelivr.net/npm/chart.js@4/dist/chart.umd.min.js"></script>
   ```
   *(Add `cdn.jsdelivr.net` to `content_security_policy` in `manifest.json` if needed.)*

### Acceptance Criteria — Phase 2

- [ ] Analytics button visible in FocusBoard UI at all times
- [ ] Clicking it hides the main dashboard and shows the panel
- [ ] Back button returns to main dashboard without page reload
- [ ] Empty-state message shown when no data exists
- [ ] No Chart.js CSP errors in the console

---

## Phase 3 — Charts & Stats

**Goal:** Render 4 data visualisations inside `#charts-container`.

### Chart 1 — Tasks Completed (Bar Chart)

- **What:** Number of tasks completed per day for the last 7 days
- **X-axis:** Day labels (Mon, Tue, … or Jul 14, Jul 15, …)
- **Y-axis:** Count (integer, min 0)
- **Colour:** Solid blue (`#4A90D9`)
- **Implementation:**
  ```js
  new Chart(ctx, {
    type: 'bar',
    data: { labels: last7DayLabels, datasets: [{ label: 'Tasks Completed', data: taskData }] },
    options: { scales: { y: { beginAtZero: true, ticks: { stepSize: 1 } } } }
  })
  ```

### Chart 2 — Focus Time per Day (Bar Chart)

- **What:** Total minutes in Focus Mode per day, last 7 days
- **Y-axis:** Minutes
- **Colour:** Green (`#27AE60`)
- Same structure as Chart 1 using `focusMinutes` per day

### Chart 3 — Focus Sessions (Line Chart)

- **What:** Number of Focus Mode sessions per day (trend line)
- **Why separate from Chart 2:** Sessions = frequency; minutes = depth. Both matter.
- **Type:** Line with filled area (`fill: true`, low opacity)
- **Colour:** Purple (`#8E44AD`)

### Chart 4 — Blocked Site Attempts (Horizontal Bar or Doughnut)

- **What:** Top blocked domains attempted during the 7-day window
- **Type:** Horizontal bar chart, one bar per domain
- **X-axis:** Attempt count
- **Implementation note:** Aggregate `blockedSiteAttempts` across all 7 daily records, then sort descending, show top 5 only
- **Empty-state:** If no attempts: render text "No blocked sites attempted — great focus!" instead of an empty chart

### Summary Stats Row (above charts)

Render 3 KPI cards in a flex row:

| Stat | Calculation |
|---|---|
| ✅ **Tasks This Week** | Sum of `tasksCompleted` across last 7 days |
| 🔥 **Focus Streak** | Longest consecutive-day streak where `focusSessionCount > 0`, counting backward from today |
| ⛔ **Temptations Blocked** | Sum of all `blockedSiteAttempts` values across last 7 days |

### Layout

```
[ ✅ 12 tasks ]  [ 🔥 4-day streak ]  [ ⛔ 7 blocked ]

[ Chart 1: Tasks Completed ]    [ Chart 2: Focus Time ]

[ Chart 3: Focus Sessions  ]    [ Chart 4: Blocked Sites ]
```

Use CSS Grid: `grid-template-columns: 1fr 1fr` for charts, full-width row for KPIs.

### Acceptance Criteria — Phase 3

- [ ] All 4 charts render without errors on a dataset with 7 days of mixed data
- [ ] KPI numbers match what was actually logged (verified via `chrome.storage.local` DevTools inspector)
- [ ] Focus Streak shows `0` on a day with no focus sessions
- [ ] Chart 4 shows empty-state text when no blocked sites have been attempted
- [ ] Charts are readable at the default new-tab page width (~1200 px) and don't overflow

---

## Phase 4 — Polish & Edge Cases

**Goal:** Make the dashboard production-quality and handle all edge cases gracefully.

### Tasks

1. **Partial day handling:** Today's data is always partial. Label today's bar as "Today" on the x-axis.

2. **Missing days:** If the user didn't open the new-tab on a given day, that day has no record. Fill missing days with zeros so the chart always shows exactly 7 bars.

3. **Destroy old Chart instances:** Before re-rendering (e.g. user closes and reopens Analytics), call `chart.destroy()` on all existing Chart.js instances to prevent the "canvas already in use" error. Store instances in a module-level `let charts = {}` map.

4. **Storage migration guard:** On `renderAnalytics()`, wrap the storage read in try/catch. If the stored value is malformed JSON, wipe it and start fresh.

5. **Accessibility:**
   - All `<canvas>` elements have `aria-label` and `role="img"`
   - KPI cards have `aria-label` values (e.g. `aria-label="12 tasks completed this week"`)

6. **Visual consistency:**
   - Match FocusBoard's existing colour palette and font for the panel header and KPI cards
   - Charts use the same font family as the rest of the extension (set via `Chart.defaults.font.family`)

7. **CSP audit:** Confirm `manifest.json` `content_security_policy` allows `cdn.jsdelivr.net`. If offline use is important, bundle Chart.js locally instead.

### Acceptance Criteria — Phase 4

- [ ] Opening Analytics twice in a row does not throw a canvas error
- [ ] A day with no new-tab opens shows a zero bar, not a gap
- [ ] Corrupted storage is silently wiped and analytics start fresh
- [ ] Extension passes Chrome Web Store CSP validation (`web_accessible_resources` and CSP are consistent)

---

## File Structure (New & Modified Files)

```
extension/
├── manifest.json              MODIFIED  (CSP, possibly new permissions)
├── newtab.html                MODIFIED  (analytics panel markup, Chart.js script tag)
├── newtab.js                  MODIFIED  (event wiring, toggle logic, renderAnalytics())
├── background.js              MODIFIED  (blocked-site event logging)
├── analytics.js               NEW       (logEvent(), readAnalytics(), date helpers)
├── analyticsCharts.js         NEW       (renderAnalytics(), chart constructors)
└── analytics.css              NEW       (panel layout, KPI card styles)
```

---

## Permissions Required

No new manifest permissions are needed beyond what FocusBoard already requests, **unless** blocked-site logging is not yet implemented. If so, confirm `webRequest` or `declarativeNetRequest` is already declared.

---

## Testing Checklist (Manual QA)

Run through this after completing all phases:

1. Open a fresh Chrome profile (to start with empty storage)
2. Complete 3 tasks on Day 1
3. Toggle Focus Mode ON, wait 2 minutes, toggle OFF (repeat twice)
4. Attempt to visit 2 blocked sites while Focus Mode is ON
5. Open Analytics → confirm:
   - Tasks bar for today = 3
   - Focus time bar for today ≥ 4 minutes
   - Sessions line for today = 2
   - Blocked sites chart shows the 2 domains
   - KPI row shows "3 tasks", "1-day streak", "2 temptations"
6. Close and reopen Analytics → no console errors
7. Check `chrome.storage.local` in DevTools → data matches the displayed numbers exactly

---

## Out-of-Scope for This Assignment

- Editing or deleting logged history
- Per-task analytics (which task was completed fastest, etc.)
- Weekly email summaries
- Cross-device sync via `chrome.storage.sync`
