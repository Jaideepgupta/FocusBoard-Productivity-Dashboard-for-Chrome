# FocusSense Content Pack
### GitHub README + LinkedIn Post + Video Script

---

## 1. GitHub README

```markdown
# 🧠 FocusSense — Distraction Intelligence for Deep Work

A Chrome extension that replaces your new-tab page with a personal productivity 
dashboard — and actually tracks whether you're being productive.

Inspired by Momentum. Built from scratch with Manifest V3.

---

## What it does

FocusSense has two layers:

**The Dashboard (what you see)**
- A full-screen wallpaper with a live clock and greeting
- A glassmorphic task widget in the top-right corner
- A "What is your main focus today?" prompt in the centre
- A Focus Mode toggle at the bottom

**The Analytics Engine (what runs quietly in the background)**
Every time you use FocusSense, it logs:
- ✅ Tasks you mark as complete
- ⏱️ How long you stayed in Focus Mode (in minutes)
- 🔁 How many Focus Mode sessions you started
- 🚫 Which distracting sites you tried to visit while Focus Mode was on

Click the 📊 button to open the Analytics overlay and see 7 days of your data.

---

## The Analytics Dashboard

**3 KPI cards at the top:**
| Stat | What it means |
|---|---|
| ✅ Tasks This Week | Total tasks completed in the last 7 days |
| 🔥 Focus Streak | Consecutive days where you had at least one focus session |
| ⛔ Temptations Blocked | Total blocked site attempts across the week |

**4 charts below:**
1. 📘 **Tasks Completed** — blue bar chart, one bar per day
2. 💚 **Focus Time (minutes)** — green bar chart, shows depth of focus
3. 💜 **Focus Sessions** — purple trend line, shows frequency of focus
4. 🔴 **Top Distracting Sites** — horizontal red bar, ranked by attempt count

---

## How data is stored

- All data lives in `chrome.storage.local` — nothing leaves your machine
- Events are aggregated into **daily summaries** (not raw logs), keeping storage tiny
- Data older than 30 days is automatically pruned on every write
- Focus duration is saved to storage (not just memory), so it survives 
  if the service worker goes to sleep

---

## Tech stack

| Layer | Technology |
|---|---|
| Extension Platform | Chrome Manifest V3 |
| Background | Service Worker (`background.js`) |
| UI | Vanilla JS + HTML + CSS |
| Charts | Chart.js 4 (bundled locally — no CDN, works offline) |
| Storage | `chrome.storage.local` |
| Styling | Glassmorphism with `backdrop-filter: blur()` |

---

## Setup

1. Clone or download this repo
2. Go to `chrome://extensions` in Chrome
3. Enable **Developer Mode** (top right)
4. Click **Load unpacked** → select the project folder
5. Open a new tab — FocusSense is live

---

## File structure

```
focussense/
├── manifest.json          Chrome extension config (Manifest V3)
├── newtab.html            Full dashboard UI + analytics overlay
├── newtab.js              Clock, tasks, focus mode, nav logic
├── analytics.js           logEvent() — writes daily summaries to storage
├── analyticsCharts.js     Reads storage, preps data, renders 4 charts + KPIs
├── analytics.css          Glassmorphic styles for both views
├── background.js          Service worker — intercepts blocked site requests
└── chart.umd.min.js       Chart.js bundled locally
```

---

## Known limitations / what's next

- `webRequest` in MV3 is read-only — full site blocking needs `declarativeNetRequest` 
  rules for production use
- Tasks are not persisted across sessions (in-memory only for now)
- No goal-setting or targets yet (e.g. "aim for 60 focus minutes today")

---

Built as Assignment 9 of a structured Chrome Extension curriculum — rated HARD.
```

---

## 2. LinkedIn Post

Shipped something I'm genuinely proud of: FocusSense, a Chrome extension that 
replaces your new-tab page with a focus dashboard — and tracks your productivity 
habits over time. 📊

It quietly logs every task you complete, every minute you spend in Focus Mode, 
and every time you try to open a distracting site while it's on. Open the analytics 
panel and you get 7 days of charts: focus time, session frequency, tasks per day, 
and a ranked list of exactly which sites are pulling your attention. The interesting 
engineering problems weren't the charts — they were getting the data layer right. 
Daily aggregation instead of raw event logging to keep storage lean. Persisting 
focus start time to chrome.storage.local instead of memory so the duration tracking 
survives Chrome's service worker lifecycle. Bundling Chart.js locally so the whole 
thing works offline and passes Manifest V3's content security policy. 

Built end-to-end with vanilla JS, no frameworks, full MV3 compliance. Code on GitHub 
— link in comments. 🔗

#ChromeExtension #JavaScript #ManifestV3 #BuildInPublic #WebDevelopment #Productivity

---

## 3. Video Script (75–90 seconds)

---

**[HOOK — 0:00 to 0:08]**

"What if every time you opened a new tab, you could see exactly how focused 
you've actually been this week? That's what I built. Let me show you."

---

**[SHOW THE DASHBOARD — 0:08 to 0:22]**

"This is FocusSense. It replaces the default Chrome new-tab page completely.

You get a live clock, a glassmorphic task widget in the corner, and a prompt 
asking what your main focus is today. At the bottom — a Focus Mode toggle 
that starts tracking the moment you turn it on."

*(Toggle Focus Mode ON — show the green indicator.)*

---

**[OPEN ANALYTICS — 0:22 to 0:32]**

"And this button here — the chart icon — opens the Analytics overlay."

*(Click 📊 button. Panel animates open.)*

"Three numbers at the top: tasks completed this week, my focus streak, and 
how many times I tried to visit a distracting site and got stopped."

---

**[WALK THE CHARTS — 0:32 to 0:55]**

"Below that, four charts.

The blue one — tasks per day. You can see which days I was actually productive.

Green — focus time in minutes. Not just turning on Focus Mode, but staying in it.

Purple trend line — number of focus sessions per day. Frequency vs depth — 
both tell a different story.

And the red one is the most honest chart in the whole thing. Every site I tried 
to visit while Focus Mode was on — ranked by how many times I tried."

*(Pause for effect.)*

"That's accountability built into your browser."

---

**[EXPLAIN THE TECH — 0:55 to 1:12]**

"Under the hood: everything is stored locally on your machine using 
chrome.storage.local — no server, no account, fully private.

I store daily summaries, not raw events, so storage stays small no matter 
how long you use it. Chart.js is bundled locally so it works offline. And 
the whole thing is built on Chrome Manifest V3 — the newest extension 
security standard.

The trickiest part? Making sure focus duration tracked correctly even when 
Chrome puts the service worker to sleep. Solved by persisting the start 
time to storage, not just memory."

---

**[CLOSE — 1:12 to 1:20]**

"Full code is on GitHub — link in the description. If you're learning Chrome 
extension development, this is Assignment 9 of a curriculum I've been working 
through. Highly recommend."

*(End card or cut.)*

---

## Filming tips

- Record screen capture first, voiceover second — it's much easier to match timing
- When showing charts, zoom in so the bars/lines are clearly visible
- The "red chart" moment at 0:55 is your best visual hook — pause there for 1–2 seconds
- Keep the Focus Mode toggle visible when you talk about it — the green dot is satisfying to watch
```
